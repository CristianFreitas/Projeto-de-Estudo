$("#quadrinho").turn({
    width: 800, // Para definir a largura da página
    height: 600, // Para definir a altura da página
});